# A3
Trabalho A3 da disciplina de Usabilidade Desenvolvimento Web Jogos e Mobile.

Intuito do trabalho foi realizar a gamificação simples de um jogo social com cunho de transito, para identificação de placas.
